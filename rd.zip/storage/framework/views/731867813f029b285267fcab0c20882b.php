

<?php $__env->startSection('title', 'Customer Details'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row mb-2">
        <div class="col-sm-6">
            <h5>Customer Details</h5>
        </div>
        <div class="col-sm-6">
            <div class="float-sm-right">
                <a href="<?php echo e(route('customers.index')); ?>" class="btn btn-default">
                    <i class="fas fa-arrow-left"></i> Back to List
                </a>
                <a href="<?php echo e(route('customers.edit', $customer)); ?>" class="btn btn-warning">
                    <i class="fas fa-edit"></i> Edit Customer
                </a>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Customer Information</h3>
                </div>
                <div class="card-body">
                    <div class="row">
                        <!-- Basic Information -->
                        <div class="col-md-6">
                            <h5 class="mb-3">Basic Information</h5>
                            <table class="table table-bordered">
                                <tr>
                                    <th style="width: 200px;">Name</th>
                                    <td><?php echo e($customer->name); ?></td>
                                </tr>
                                <tr>
                                    <th>Email</th>
                                    <td><?php echo e($customer->email); ?></td>
                                </tr>
                                <tr>
                                    <th>Mobile Number</th>
                                    <td><?php echo e($customer->mobile_number); ?></td>
                                </tr>
                                <tr>
                                    <th>Phone Number</th>
                                    <td><?php echo e($customer->phone); ?></td>
                                </tr>
                                <tr>
                                    <th>Date of Birth</th>
                                    <td><?php echo e($customer->date_of_birth->format('d M Y')); ?></td>
                                </tr>
                                <tr>
                                    <th>Address</th>
                                    <td><?php echo e($customer->address); ?></td>
                                </tr>
                                <tr>
                                    <th>Agent</th>
                                    <td>
                                        <?php if($customer->agent): ?>
                                            <a href="<?php echo e(route('agents.show', $customer->agent)); ?>">
                                                <?php echo e($customer->agent->name); ?>

                                            </a>
                                        <?php else: ?>
                                            <span class="text-muted">No Agent Assigned</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            </table>
                        </div>

                        <!-- ID Documents -->
                        <!-- <div class="col-md-6">
                            <h5 class="mb-3">ID Documents</h5>
                            <table class="table table-bordered">
                                <tr>
                                    <th style="width: 200px;">Aadhar Number</th>
                                    <td><?php echo e($customer->aadhar_number ?? 'Not Provided'); ?></td>
                                </tr>
                                <tr>
                                    <th>PAN Number</th>
                                    <td><?php echo e($customer->pan_number ?? 'Not Provided'); ?></td>
                                </tr>
                                <tr>
                                    <th>Aadhar Card</th>
                                    <td>
                                        <?php if($customer->aadhar_file): ?>
                                            <a href="<?php echo e(Storage::url($customer->aadhar_file)); ?>" target="_blank">
                                                View Document
                                            </a>
                                        <?php else: ?>
                                            Not Uploaded
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <tr>
                                    <th>PAN Card</th>
                                    <td>
                                        <?php if($customer->pan_file): ?>
                                            <a href="<?php echo e(Storage::url($customer->pan_file)); ?>" target="_blank">
                                                View Document
                                            </a>
                                        <?php else: ?>
                                            Not Uploaded
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <tr>
                                    <th>Photo</th>
                                    <td>
                                        <?php if($customer->photo): ?>
                                            <img src="<?php echo e(Storage::url($customer->photo)); ?>" 
                                                 alt="Customer Photo" 
                                                 style="max-width: 100px; max-height: 100px;">
                                        <?php else: ?>
                                            Not Uploaded
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            </table>

                            <h5 class="mt-4 mb-3">Savings Account</h5>
                            <table class="table table-bordered">
                                <tr>
                                    <th style="width: 200px;">Has Savings Account</th>
                                    <td>
                                        <?php if($customer->has_savings_account): ?>
                                            <span class="badge badge-success">Yes</span>
                                        <?php else: ?>
                                            <span class="badge badge-danger">No</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php if($customer->has_savings_account): ?>
                                <tr>
                                    <th>CIF ID</th>
                                    <td><?php echo e($customer->cif_id); ?></td>
                                </tr>
                                <tr>
                                    <th>Account Number</th>
                                    <td><?php echo e($customer->savings_account_no); ?></td>
                                </tr>
                                <?php endif; ?>
                            </table>
                        </div> -->
                    </div>

                    <!-- RD Accounts -->
                    <div class="row mt-4">
                        <div class="col-12">
                            <h5 class="mb-3">RD Accounts</h5>
                            <?php if($customer->rdAccounts->count() > 0): ?>
                                <div class="table-responsive">
                                    <table class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <th>Account Number</th>
                                                <th>Monthly Amount</th>
                                                <th>Duration</th>
                                                <th>Start Date</th>
                                                <th>Maturity Date</th>
                                                <th>Status</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $customer->rdAccounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($account->account_number); ?></td>
                                                    <td>₹<?php echo e(number_format($account->monthly_amount, 2)); ?></td>
                                                    <td><?php echo e($account->duration_months); ?> months</td>
                                                    <td><?php echo e($account->start_date->format('d M Y')); ?></td>
                                                    <td><?php echo e($account->maturity_date->format('d M Y')); ?></td>
                                                    <td>
                                                        <span class="badge badge-<?php echo e($account->status === 'active' ? 'success' : ($account->status === 'matured' ? 'info' : 'danger')); ?>">
                                                            <?php echo e(ucfirst($account->status)); ?>

                                                        </span>
                                                    </td>
                                                    <td>
                                                        <a href="<?php echo e(route('admin.rd-accounts.show', $account)); ?>"
                                                           class="btn btn-sm btn-info"
                                                           title="View Details">
                                                            <i class="fas fa-eye"></i>
                                                        </a>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php else: ?>
                                <div class="alert alert-info">
                                    No RD accounts found for this customer.
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\RD Agent20828\RD Agent\resources\views/admin/customers/show.blade.php ENDPATH**/ ?>