

<?php $__env->startSection('title', 'Manage Customers'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row mb-2">
        <div class="col-sm-6">
            <h5>Manage Customers</h5>
        </div>
        <div class="col-sm-6">
            <div class="float-sm-right">
                <a href="<?php echo e(route('customers.create')); ?>" class="btn btn-primary">
                    <i class="fas fa-plus"></i> Add New Customer
                </a>
            </div>
        </div>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo e(session('error')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <!-- Summary Cards -->
    <div class="row mb-4">
        <div class="col-xl-3 col-md-6">
            <div class="card bg-primary text-white mb-4">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <div class="small text-white-50">Total Customers</div>
                            <div class="font-weight-bold"><?php echo e($summary['total_customers']); ?></div>
                        </div>
                        <div>
                            <i class="fas fa-users fa-2x opacity-50"></i>
                        </div>
                    </div>
                </div>
                <div class="card-footer d-flex align-items-center justify-content-between">
                    <div class="small text-white">
                        New this month: <?php echo e($summary['recent_customers']); ?>

                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="card bg-success text-white mb-4">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <div class="small text-white-50">With RD Accounts</div>
                            <div class="font-weight-bold"><?php echo e($summary['with_rd_accounts']); ?></div>
                        </div>
                        <div>
                            <i class="fas fa-piggy-bank fa-2x opacity-50"></i>
                        </div>
                    </div>
                </div>
                <div class="card-footer d-flex align-items-center justify-content-between">
                    <div class="small text-white">Total RD Accounts: <?php echo e($summary['total_rd_accounts']); ?></div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="card bg-warning text-white mb-4">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <div class="small text-white-50">Without RD Accounts</div>
                            <div class="font-weight-bold"><?php echo e($summary['without_rd_accounts']); ?></div>
                        </div>
                        <div>
                            <i class="fas fa-user-clock fa-2x opacity-50"></i>
                        </div>
                    </div>
                </div>
                <div class="card-footer d-flex align-items-center justify-content-between">
                    <div class="small text-white">Potential customers for RD</div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="card bg-info text-white mb-4">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <div class="small text-white-50">Average RD Accounts</div>
                            <div class="font-weight-bold">
                                <?php echo e(number_format($summary['with_rd_accounts'] > 0 ? $summary['total_rd_accounts'] / $summary['with_rd_accounts'] : 0, 1)); ?>

                            </div>
                        </div>
                        <div>
                            <i class="fas fa-chart-line fa-2x opacity-50"></i>
                        </div>
                    </div>
                </div>
                <div class="card-footer d-flex align-items-center justify-content-between">
                    <div class="small text-white">Per customer with RD</div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Filters</h3>
                    <div class="card-tools">
                        <button type="button" class="btn btn-tool" data-card-widget="collapse">
                            <i class="fas fa-minus"></i>
                        </button>
                    </div>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('customers.index')); ?>" method="GET" class="form-inline">
                        <div class="form-group mb-2 mr-2">
                            <label for="search" class="mr-2">Search:</label>
                            <input type="text" class="form-control" id="search" name="search" 
                                   value="<?php echo e(request('search')); ?>" placeholder="Name, Email, Mobile...">
                        </div>
                        <div class="form-group mb-2 mr-2">
                            <label for="agent_id" class="mr-2">Agent:</label>
                            <select class="form-control" id="agent_id" name="agent_id">
                                <option value="">All Agents</option>
                                <?php $__currentLoopData = $agents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($agent->id); ?>" <?php echo e(request('agent_id') == $agent->id ? 'selected' : ''); ?>>
                                        <?php echo e($agent->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group mb-2 mr-2">
                            <label for="date_range" class="mr-2">Registration Date:</label>
                            <input type="text" class="form-control" id="date_range" name="date_range" 
                                   value="<?php echo e(request('date_range')); ?>" placeholder="Select date range">
                        </div>
                        <div class="form-group mb-2 mr-2">
                            <label for="has_rd_account" class="mr-2">RD Account:</label>
                            <select class="form-control" id="has_rd_account" name="has_rd_account">
                                <option value="">All</option>
                                <option value="yes" <?php echo e(request('has_rd_account') === 'yes' ? 'selected' : ''); ?>>With RD Account</option>
                                <option value="no" <?php echo e(request('has_rd_account') === 'no' ? 'selected' : ''); ?>>Without RD Account</option>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary mb-2">Filter</button>
                        <a href="<?php echo e(route('customers.index')); ?>" class="btn btn-default mb-2 ml-2">Reset</a>
                    </form>
                </div>
            </div>

            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Customers List</h3>
                    <div class="card-tools">
                        <a href="<?php echo e(route('customers.export')); ?>?<?php echo e(http_build_query(request()->query())); ?>" 
                           class="btn btn-success btn-sm">
                            <i class="fas fa-file-excel"></i> Export
                        </a>
                    </div>
                </div>
                <div class="card-body table-responsive p-0">
                    <table class="table table-hover text-nowrap">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Mobile</th>
                                <th>Agent</th>
                                <th>Registration Date</th>
                                <th>RD Accounts</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($customer->id); ?></td>
                                    <td><?php echo e($customer->name); ?></td>
                                    <td><?php echo e($customer->email); ?></td>
                                    <td><?php echo e($customer->mobile_number); ?></td>
                                    <td>
                                        <?php if($customer->agent): ?>
                                            <a href="<?php echo e(route('agents.show', $customer->agent)); ?>">
                                                <?php echo e($customer->agent->name); ?>

                                            </a>
                                        <?php else: ?>
                                            <span class="text-muted">No Agent</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($customer->created_at->format('d M Y')); ?></td>
                                    <td>
                                        <?php if($customer->rdAccounts->count() > 0): ?>
                                            <span class="badge badge-success"><?php echo e($customer->rdAccounts->count()); ?></span>
                                        <?php else: ?>
                                            <span class="badge badge-danger">0</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('customers.show', $customer)); ?>" 
                                           class="btn btn-sm btn-info" title="View Details">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <a href="<?php echo e(route('customers.edit', $customer)); ?>" 
                                           class="btn btn-sm btn-warning" title="Edit">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <form action="<?php echo e(route('customers.destroy', $customer)); ?>" 
                                              method="POST" class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-sm btn-danger" 
                                                    title="Delete" onclick="return confirm('Are you sure?')">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="8" class="text-center">No customers found.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <div class="card-footer clearfix">
                    <?php echo e($customers->links()); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/moment/moment.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
<script>
$(function() {
    // Initialize date range picker
    $('#date_range').daterangepicker({
        autoUpdateInput: false,
        locale: {
            cancelLabel: 'Clear',
            format: 'DD/MM/YYYY'
        }
    });

    $('#date_range').on('apply.daterangepicker', function(ev, picker) {
        $(this).val(picker.startDate.format('DD/MM/YYYY') + ' - ' + picker.endDate.format('DD/MM/YYYY'));
    });

    $('#date_range').on('cancel.daterangepicker', function(ev, picker) {
        $(this).val('');
    });
});
</script>
<?php $__env->stopPush(); ?> 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\RD Agent20828\RD Agent\resources\views/admin/customers/index.blade.php ENDPATH**/ ?>