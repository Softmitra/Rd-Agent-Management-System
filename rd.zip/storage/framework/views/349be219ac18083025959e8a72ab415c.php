<footer class="main-footer" style="font-size: 14px;">
    <strong>Copyright &copy; <?php echo e(date('Y')); ?> <a href="#">RD Agent System</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
        <b>Version</b> 1.0.0
    </div>
</footer>
<?php /**PATH C:\xampp\htdocs\RD Agent20828\RD Agent\resources\views/layouts/footer.blade.php ENDPATH**/ ?>