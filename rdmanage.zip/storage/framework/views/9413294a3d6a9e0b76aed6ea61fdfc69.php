<!-- Main Sidebar Container -->
<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="<?php echo e(route('dashboard')); ?>" class="brand-link">
        <!-- <img src="<?php echo e(asset('images/logo.png')); ?>" alt="RD Agent Logo" class="brand-image img-circle elevation-3" style="opacity: .8"> -->
        <span class="brand-text font-weight-light">RD Agent</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
        <!-- Sidebar Menu -->
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                <li class="nav-item">
                    <a href="<?php echo e(route('dashboard')); ?>" class="nav-link <?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>">
                        <i class="nav-icon fas fa-tachometer-alt"></i>
                        <p>Dashboard</p>
                    </a>
                </li>
                
                <?php if(Auth::user()->hasRole('admin')): ?>
                <li class="nav-item">
                    <a href="<?php echo e(route('customers.index')); ?>" class="nav-link <?php echo e(request()->routeIs('customers.*') ? 'active' : ''); ?>">
                        <i class="nav-icon fas fa-users"></i>
                        <p>All Customers</p>
                    </a>
                </li>
                <?php else: ?>
                <li class="nav-item">
                    <a href="<?php echo e(route('agent.customers.index')); ?>" class="nav-link <?php echo e(request()->routeIs('agent.customers.*') ? 'active' : ''); ?>">
                        <i class="nav-icon fas fa-users"></i>
                        <p>My Customers</p>
                    </a>
                </li>
                <?php endif; ?>
                
                <?php if(auth()->user()->id == 1): ?>
                <li class="nav-item">
                    <a href="<?php echo e(route('admin.rd-accounts.index')); ?>" class="nav-link <?php echo e(request()->routeIs('admin.rd-accounts.*') ? 'active' : ''); ?>">
                        <i class="nav-icon fas fa-piggy-bank"></i>
                        <p>RD Accounts</p>
                    </a>
                </li>
                <?php else: ?>
                <li class="nav-item">
                    <a href="<?php echo e(route('agent.rd-agent-accounts.index')); ?>" class="nav-link <?php echo e(request()->routeIs('agent.rd-agent-accounts.*') ? 'active' : ''); ?>">
                        <i class="nav-icon fas fa-piggy-bank"></i>
                        <p>RD Agent Accounts</p>
                    </a>
                </li>
                <?php endif; ?>
                
                <li class="nav-item">
                    <a href="<?php echo e(route('payments.index')); ?>" class="nav-link <?php echo e(request()->routeIs('payments.*') ? 'active' : ''); ?>">
                        <i class="nav-icon fas fa-money-bill-wave"></i>
                        <p>Payments</p>
                    </a>
                </li>
                
                <li class="nav-item">
                    <a href="<?php echo e(route('collections.index')); ?>" class="nav-link <?php echo e(request()->routeIs('collections.*') ? 'active' : ''); ?>">
                        <i class="nav-icon fas fa-coins"></i>
                        <p>Collection Entry</p>
                    </a>
                </li>
                
                <!-- Lot Management -->
                <?php if(auth()->user()->id == 1): ?>
                <li class="nav-item">
                    <a href="<?php echo e(route('admin.lots.index')); ?>" class="nav-link <?php echo e(request()->routeIs('admin.lots.*') ? 'active' : ''); ?>">
                        <i class="nav-icon fas fa-box"></i>
                        <p>Lot Management</p>
                    </a>
                </li>
                <?php else: ?>
                <li class="nav-item">
                    <a href="<?php echo e(route('agent.lots.index')); ?>" class="nav-link <?php echo e(request()->routeIs('agent.lots.*') ? 'active' : ''); ?>">
                        <i class="nav-icon fas fa-box"></i>
                        <p>Lot Management</p>
                    </a>
                </li>
                <?php endif; ?>
                
                <!-- Excel Import for all users -->
                <?php if(Auth::user()->hasRole('admin')): ?>
                <li class="nav-item">
                    <a href="<?php echo e(route('admin.excel-import.index')); ?>" class="nav-link <?php echo e(request()->routeIs('admin.excel-import.*') ? 'active' : ''); ?>">
                        <i class="nav-icon fas fa-sync-alt text-success"></i>
                        <p>Excel Import</p>
                        <span class="badge badge-success right">Sync</span>
                    </a>
                </li>
                <?php else: ?>
                <li class="nav-item">
                    <a href="<?php echo e(route('agent.excel-import.index')); ?>" class="nav-link <?php echo e(request()->routeIs('agent.excel-import.*') ? 'active' : ''); ?>">
                        <i class="nav-icon fas fa-sync-alt text-success"></i>
                        <p>Excel Import</p>
                        <span class="badge badge-success right">Sync</span>
                    </a>
                </li>
                <?php endif; ?>
                
                <?php if(Auth::user()->hasRole('admin')): ?>
                <li class="nav-header">ADMINISTRATION</li>
                
                <li class="nav-item">
                    <a href="<?php echo e(route('agents.index')); ?>" class="nav-link <?php echo e(request()->routeIs('agents.*') ? 'active' : ''); ?>">
                        <i class="nav-icon fas fa-user-tie"></i>
                        <p>Agents</p>
                    </a>
                </li>
                
                <li class="nav-item">
                    <a href="<?php echo e(route('roles.index')); ?>" class="nav-link <?php echo e(request()->routeIs('roles.*') ? 'active' : ''); ?>">
                        <i class="nav-icon fas fa-user-shield"></i>
                        <p>Roles</p>
                    </a>
                </li>
                
                <li class="nav-item">
                        <a href="<?php echo e(route('admin.logs.index')); ?>" class="nav-link <?php echo e(request()->routeIs('admin.logs.*') ? 'active' : ''); ?>" target="_blank">
                            <i class="nav-icon fas fa-history"></i>
                            <p>Activity Logs</p>
                        </a>
                </li>
                <?php endif; ?>
            </ul>
        </nav>
    </div>
</aside>
<?php /**PATH C:\xampp\htdocs\RD Agent20828\RD Agent\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>