<!-- Navbar -->
<nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
        <li class="nav-item">
            <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
        </li>
    </ul>

    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">
        <!-- Notifications -->
        <?php if(Auth::user()->hasRole('admin')): ?>
            <li class="nav-item">
                <?php echo $__env->make('components.notification-bell', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </li>
        <?php endif; ?>
        
        <!-- User Dropdown Menu -->
        <li class="nav-item dropdown user-menu">
            <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                <i class="fas fa-user-circle"></i>
                <span class="d-none d-md-inline"><?php echo e(Auth::user()->name ?? 'Super Admin'); ?></span>
            </a>
            <ul class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
                <!-- User image -->
                <li class="user-header bg-primary">
                    <i class="fas fa-user-circle fa-3x"></i>
                    <p>
                        <?php echo e(Auth::user()->name ?? 'Super Admin'); ?>

                        <small>Member since <?php echo e(Auth::user()->created_at ? Auth::user()->created_at->format('M. Y') : 'N/A'); ?></small>
                    </p>
                </li>
                <!-- Menu Footer-->
                <li class="user-footer">
                    <a href="<?php echo e(route('profile.edit')); ?>" class="btn btn-default btn-flat">Profile</a>

                    <form action="<?php echo e(route('logout')); ?>" method="POST" class="d-inline">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-default btn-flat float-right">Sign out</button>
                    </form>
                </li>
            </ul>
        </li>
    </ul>
</nav> <?php /**PATH C:\xampp\htdocs\RD Agent20828\RD Agent\resources\views/layouts/header.blade.php ENDPATH**/ ?>