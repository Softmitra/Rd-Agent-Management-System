<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">Create Payment</h5>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('payments.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>

                            <div class="row">
                                <?php if(isset($rdAccount)): ?>
                                    <div class="col-md-12 mb-3">
                                        <label for="rd_account_id" class="form-label">RD Account</label>
                                        <input type="hidden" name="rd_account_id" value="<?php echo e($rdAccount->id); ?>">
                                        <input type="text" class="form-control"
                                            value="<?php echo e($rdAccount->account_number); ?> - <?php echo e($rdAccount->customer->name ?? ''); ?>"
                                            disabled>
                                    </div>
                                <?php else: ?>
                                    <div class="col-md-6 mb-3">
                                        <label for="rd_account_id" class="form-label">RD Account ID</label>
                                        <input type="number" class="form-control" name="rd_account_id" id="rd_account_id"
                                            value="<?php echo e(old('rd_account_id')); ?>" required>
                                    </div>
                                <?php endif; ?>

                                <div class="col-md-6 mb-3">
                                    <label for="amount" class="form-label">Amount</label>
                                    <input type="number" step="0.01" class="form-control" name="amount" id="amount"
                                        value="<?php echo e(old('amount', isset($rdAccount) ? $rdAccount->monthly_amount : '')); ?>"
                                        required>
                                </div>

                                <div class="col-md-6 mb-3">
                                    <label for="payment_date" class="form-label">Payment Date</label>
                                    <input type="date" class="form-control" name="payment_date" id="payment_date"
                                        value="<?php echo e(old('payment_date', date('Y-m-d'))); ?>" required>
                                </div>

                                <div class="col-md-6 mb-3">
                                    <label for="payment_method" class="form-label">Payment Method</label>
                                    <select class="form-control" name="payment_method" id="payment_method" required>
                                        <option value="">Select Method</option>
                                        <option value="cash" <?php echo e(old('payment_method') == 'cash' ? 'selected' : ''); ?>>Cash
                                        </option>
                                        <option value="upi" <?php echo e(old('payment_method') == 'upi' ? 'selected' : ''); ?>>UPI
                                        </option>
                                        <option value="bank_transfer"
                                            <?php echo e(old('payment_method') == 'bank_transfer' ? 'selected' : ''); ?>>Bank Transfer
                                        </option>
                                        <option value="cheque" <?php echo e(old('payment_method') == 'cheque' ? 'selected' : ''); ?>>
                                            Cheque</option>
                                    </select>
                                </div>

                                <div class="col-md-6 mb-3">
                                    <label for="transaction_id" class="form-label">Transaction ID</label>
                                    <input type="text" class="form-control" name="transaction_id" id="transaction_id"
                                        value="<?php echo e(old('transaction_id')); ?>">
                                </div>

                                <div class="col-md-6 mb-3">
                                    <label for="remarks" class="form-label">Remarks</label>
                                    <textarea class="form-control" name="remarks" id="remarks" rows="2"><?php echo e(old('remarks')); ?></textarea>
                                </div>
                            </div>

                            <button type="submit" class="btn btn-primary">Create Payment</button>
                        </form>

                    </div>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>




<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Create Payment</h1>
    <form action="<?php echo e(route('payments.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        
        <?php if(isset($rdAccount)): ?>
            <div class="mb-3">
                <label for="rd_account_id" class="form-label">RD Account</label>
                <input type="hidden" name="rd_account_id" value="<?php echo e($rdAccount->id); ?>">
                <input type="text" class="form-control" value="<?php echo e($rdAccount->account_number); ?> - <?php echo e($rdAccount->customer->name ?? ''); ?>" disabled>
            </div>
        <?php else: ?>
            <div class="mb-3">
                <label for="rd_account_id" class="form-label">RD Account ID</label>
                <input type="number" class="form-control" name="rd_account_id" id="rd_account_id" value="<?php echo e(old('rd_account_id')); ?>" required>
            </div>
        <?php endif; ?>

        <div class="mb-3">
            <label for="amount" class="form-label">Amount</label>
            <input type="number" step="0.01" class="form-control" name="amount" id="amount" value="<?php echo e(old('amount', isset($rdAccount) ? $rdAccount->monthly_amount : '')); ?>" required>
        </div>

        <div class="mb-3">
            <label for="payment_date" class="form-label">Payment Date</label>
            <input type="date" class="form-control" name="payment_date" id="payment_date" value="<?php echo e(old('payment_date', date('Y-m-d'))); ?>" required>
        </div>

        <div class="mb-3">
            <label for="payment_method" class="form-label">Payment Method</label>
            <select class="form-control" name="payment_method" id="payment_method" required>
                <option value="">Select Method</option>
                <option value="cash" <?php echo e(old('payment_method') == 'cash' ? 'selected' : ''); ?>>Cash</option>
                <option value="upi" <?php echo e(old('payment_method') == 'upi' ? 'selected' : ''); ?>>UPI</option>
                <option value="bank_transfer" <?php echo e(old('payment_method') == 'bank_transfer' ? 'selected' : ''); ?>>Bank Transfer</option>
                <option value="cheque" <?php echo e(old('payment_method') == 'cheque' ? 'selected' : ''); ?>>Cheque</option>
            </select>
        </div>

        <div class="mb-3">
            <label for="transaction_id" class="form-label">Transaction ID</label>
            <input type="text" class="form-control" name="transaction_id" id="transaction_id" value="<?php echo e(old('transaction_id')); ?>">
        </div>

        <div class="mb-3">
            <label for="remarks" class="form-label">Remarks</label>
            <textarea class="form-control" name="remarks" id="remarks" rows="2"><?php echo e(old('remarks')); ?></textarea>
        </div>

        <button type="submit" class="btn btn-primary">Create Payment</button>
    </form>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\RD Agent20828\RD Agent\resources\views/admin/payments/create.blade.php ENDPATH**/ ?>