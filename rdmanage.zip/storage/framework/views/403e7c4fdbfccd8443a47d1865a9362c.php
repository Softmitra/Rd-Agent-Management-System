

<?php $__env->startSection('title', 'View Agent'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row mb-2">
        <div class="col-sm-6">
            <h1>View Agent</h1>
        </div>
        <div class="col-sm-6">
            <div class="float-sm-right">
                <a href="<?php echo e(route('agents.index')); ?>" class="btn btn-default">
                    <i class="fas fa-arrow-left"></i> Back to List
                </a>
                <a href="<?php echo e(route('agents.edit', $agent)); ?>" class="btn btn-warning">
                    <i class="fas fa-edit"></i> Edit Agent
                </a>
            </div>
        </div>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-md-8">
            <!-- Agent Details Card -->
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Agent Details</h3>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Agent ID</label>
                                <p class="form-control-static"><?php echo e($agent->agent_id); ?></p>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Name</label>
                                <p class="form-control-static"><?php echo e($agent->name); ?></p>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Email</label>
                                <p class="form-control-static"><?php echo e($agent->email); ?></p>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Branch</label>
                                <p class="form-control-static"><?php echo e($agent->branch); ?></p>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Aadhar Number</label>
                                <p class="form-control-static"><?php echo e($agent->aadhar_number); ?></p>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>PAN Number</label>
                                <p class="form-control-static"><?php echo e($agent->pan_number); ?></p>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Contact Phone</label>
                                <p class="form-control-static"><?php echo e($agent->contact_info['phone'] ?? 'Not provided'); ?></p>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Address</label>
                                <p class="form-control-static"><?php echo e($agent->contact_info['address'] ?? 'Not provided'); ?></p>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label>Documents</label>
                                <div class="row">
                                    <?php if($agent->aadhar_file): ?>
                                        <div class="col-md-6">
                                            <div class="card document-card">
                                                <div class="card-header">
                                                    <h6 class="mb-0">
                                                        <i class="fas fa-id-card text-primary"></i> Aadhar Card
                                                    </h6>
                                                </div>
                                                <div class="card-body text-center">
                                                    <div class="document-preview mb-3">
                                                        <?php
                                                            $fileExtension = pathinfo($agent->aadhar_file, PATHINFO_EXTENSION);
                                                            $isPdf = strtolower($fileExtension) === 'pdf';
                                                        ?>
                                                        <?php if($isPdf): ?>
                                                            <i class="fas fa-file-pdf fa-4x text-danger"></i>
                                                            <p class="mt-2 text-muted">PDF Document</p>
                                                        <?php else: ?>
                                                            <img src="<?php echo e(route('agents.document', [$agent, 'aadhar'])); ?>" alt="Aadhar Card" class="img-thumbnail" style="max-height: 120px; cursor: pointer;" onclick="viewDocument('<?php echo e(route('agents.document', [$agent, 'aadhar'])); ?>', 'Aadhar Card', 'image')">
                                                        <?php endif; ?>
                                                    </div>
                                                    <button type="button" class="btn btn-primary btn-sm" onclick="viewDocument('<?php echo e(route('agents.document', [$agent, 'aadhar'])); ?>', 'Aadhar Card', '<?php echo e($isPdf ? 'pdf' : 'image'); ?>')">
                                                        <i class="fas fa-eye"></i> View Document
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                    <?php if($agent->pan_file): ?>
                                        <div class="col-md-6">
                                            <div class="card document-card">
                                                <div class="card-header">
                                                    <h6 class="mb-0">
                                                        <i class="fas fa-id-card text-success"></i> PAN Card
                                                    </h6>
                                                </div>
                                                <div class="card-body text-center">
                                                    <div class="document-preview mb-3">
                                                        <?php
                                                            $fileExtension = pathinfo($agent->pan_file, PATHINFO_EXTENSION);
                                                            $isPdf = strtolower($fileExtension) === 'pdf';
                                                        ?>
                                                        <?php if($isPdf): ?>
                                                            <i class="fas fa-file-pdf fa-4x text-danger"></i>
                                                            <p class="mt-2 text-muted">PDF Document</p>
                                                        <?php else: ?>
                                                            <img src="<?php echo e(route('agents.document', [$agent, 'pan'])); ?>" alt="PAN Card" class="img-thumbnail" style="max-height: 120px; cursor: pointer;" onclick="viewDocument('<?php echo e(route('agents.document', [$agent, 'pan'])); ?>', 'PAN Card', 'image')">
                                                        <?php endif; ?>
                                                    </div>
                                                    <button type="button" class="btn btn-success btn-sm" onclick="viewDocument('<?php echo e(route('agents.document', [$agent, 'pan'])); ?>', 'PAN Card', '<?php echo e($isPdf ? 'pdf' : 'image'); ?>')">
                                                        <i class="fas fa-eye"></i> View Document
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                    <?php if(!$agent->aadhar_file && !$agent->pan_file): ?>
                                        <div class="col-12">
                                            <div class="alert alert-warning">
                                                <i class="fas fa-exclamation-triangle"></i> No documents uploaded yet.
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <!-- Status Card -->
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Account Status</h3>
                </div>
                <div class="card-body">
                    <div class="form-group">
                        <label>Verification Status</label>
                        <div>
                            <?php if($agent->is_verified): ?>
                                <span class="badge badge-success">Verified</span>
                                <?php if($agent->verified_at): ?>
                                <p class="text-muted mt-1">
                                    Verified on <?php echo e($agent->verified_at->format('M d, Y h:i A')); ?>

                                    <?php if($agent->verifier): ?>
                                        by <?php echo e($agent->verifier->name); ?>

                                    <?php endif; ?>
                                </p>
                                <?php endif; ?>
                                <?php if($agent->verification_remarks): ?>
                                    <p class="text-muted">
                                        Remarks: <?php echo e($agent->verification_remarks); ?>

                                    </p>
                                <?php endif; ?>
                            <?php else: ?>
                                <span class="badge badge-warning">Pending Verification</span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Account Status</label>
                        <div>
                            <?php if($agent->is_active): ?>
                                <span class="badge badge-info">Active</span>
                                <?php if($agent->account_expires_at): ?>
                                    <p class="text-muted mt-1">
                                        Expires on <?php echo e($agent->account_expires_at->format('M d, Y')); ?>

                                    </p>
                                <?php endif; ?>
                            <?php else: ?>
                                <span class="badge badge-danger">Inactive</span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <?php if(auth()->user()->hasRole('admin')): ?>
                        <hr>
                        <div class="form-group">
                            <label>Actions</label>
                            <div>
                                <?php if(!$agent->is_verified): ?>
                                    <button type="button" class="btn btn-success verify-agent mb-2 btn-block">
                                        <i class="fas fa-check"></i> Verify Agent
                                    </button>
                                <?php else: ?>
                                    <form action="<?php echo e(route('agents.unverify', $agent)); ?>" method="POST" class="mb-2">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-warning btn-block">
                                            <i class="fas fa-times"></i> Unverify Agent
                                        </button>
                                    </form>
                                <?php endif; ?>

                                <?php if($agent->is_active): ?>
                                    <form action="<?php echo e(route('agents.deactivate', $agent)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-danger btn-block">
                                            <i class="fas fa-ban"></i> Deactivate Account
                                        </button>
                                    </form>
                                <?php else: ?>
                                    <button type="button" class="btn btn-success activate-agent btn-block">
                                        <i class="fas fa-check-circle"></i> Activate Account
                                    </button>
                                <?php endif; ?>

                                <?php if($agent->is_active): ?>
                                    <button type="button" class="btn btn-info update-expiration btn-block mt-2">
                                        <i class="fas fa-calendar-alt"></i> Update Expiration Date
                                    </button>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Timestamps Card -->
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Timestamps</h3>
                </div>
                <div class="card-body">
                    <div class="form-group">
                        <label>Created At</label>
                        <p class="form-control-static"><?php echo e($agent->created_at ? $agent->created_at->format('M d, Y h:i A') : 'N/A'); ?></p>
                    </div>
                    <div class="form-group">
                        <label>Last Updated</label>
                        <p class="form-control-static"><?php echo e($agent->updated_at ? $agent->updated_at->format('M d, Y h:i A') : 'N/A'); ?></p>
                    </div>
                    <?php if($agent->email_verified_at): ?>
                        <div class="form-group">
                            <label>Email Verified At</label>
                            <p class="form-control-static"><?php echo e($agent->email_verified_at->format('M d, Y h:i A')); ?></p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Verify Agent Modal -->
<div class="modal fade" id="verifyAgentModal" tabindex="-1" role="dialog" aria-labelledby="verifyAgentModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <form action="<?php echo e(route('agents.verify', $agent)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-header">
                    <h5 class="modal-title" id="verifyAgentModalLabel">Verify Agent</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label for="remarks">Verification Remarks</label>
                        <textarea class="form-control" id="remarks" name="remarks" rows="3" placeholder="Enter any remarks about the verification"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Verify Agent</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Activate Agent Modal -->
<div class="modal fade" id="activateAgentModal" tabindex="-1" role="dialog" aria-labelledby="activateAgentModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <form action="<?php echo e(route('agents.activate', $agent)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-header">
                    <h5 class="modal-title" id="activateAgentModalLabel">Activate Agent</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label for="expires_at">Account Expiry Date</label>
                        <input type="date" class="form-control" id="expires_at" name="expires_at">
                        <small class="form-text text-muted">Leave blank for no expiry date</small>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Activate Agent</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Update Expiration Modal -->
<div class="modal fade" id="updateExpirationModal" tabindex="-1" role="dialog" aria-labelledby="updateExpirationModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <form action="<?php echo e(route('agents.update-expiration', $agent)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-header">
                    <h5 class="modal-title" id="updateExpirationModalLabel">Update Expiration Date</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label for="update_expires_at">Account Expiry Date</label>
                        <input type="date" class="form-control" id="update_expires_at" name="expires_at" 
                               value="<?php echo e($agent->account_expires_at ? $agent->account_expires_at->format('Y-m-d') : ''); ?>">
                        <small class="form-text text-muted">Leave blank for no expiry date</small>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Update Expiration</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Document Viewer Modal -->
<div class="modal fade" id="documentViewerModal" tabindex="-1" role="dialog" aria-labelledby="documentViewerModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="documentViewerModalLabel">Document Viewer</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body text-center" style="min-height: 500px;">
                <div id="documentContent">
                    <!-- Document content will be loaded here -->
                </div>
            </div>
            <div class="modal-footer">
                <a id="downloadLink" href="#" target="_blank" class="btn btn-primary">
                    <i class="fas fa-download"></i> Download
                </a>
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
$(function() {
    // Handle verify agent modal
    $('.verify-agent').click(function(e) {
        e.preventDefault();
        $('#verifyAgentModal').modal('show');
    });

    // Handle activate agent modal
    $('.activate-agent').click(function(e) {
        e.preventDefault();
        $('#activateAgentModal').modal('show');
    });
    
    // Handle update expiration modal
    $('.update-expiration').click(function(e) {
        e.preventDefault();
        $('#updateExpirationModal').modal('show');
    });
});

// Function to view documents
function viewDocument(url, title, type) {
    $('#documentViewerModalLabel').text(title);
    $('#downloadLink').attr('href', url);
    
    if (type === 'pdf') {
        $('#documentContent').html(`
            <embed src="${url}" type="application/pdf" width="100%" height="500px" style="border: none;">
            <p class="mt-3 text-muted">If the PDF doesn't load, <a href="${url}" target="_blank">click here to open in a new tab</a></p>
        `);
    } else {
        $('#documentContent').html(`
            <img src="${url}" alt="${title}" class="img-fluid" style="max-width: 100%; max-height: 70vh; border: 1px solid #ddd; border-radius: 4px;">
        `);
    }
    
    $('#documentViewerModal').modal('show');
}
</script>

<style>
.document-card {
    margin-bottom: 20px;
    transition: transform 0.2s ease-in-out;
    border: 1px solid #e3e6f0;
}

.document-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
}

.document-preview {
    min-height: 140px;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
}

.document-card .card-header {
    background-color: #f8f9fc;
    border-bottom: 1px solid #e3e6f0;
}

.img-thumbnail {
    border-radius: 8px;
    transition: transform 0.2s ease-in-out;
}

.img-thumbnail:hover {
    transform: scale(1.05);
}
</style>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\RD Agent20828\RD Agent\resources\views/admin/agents/show.blade.php ENDPATH**/ ?>