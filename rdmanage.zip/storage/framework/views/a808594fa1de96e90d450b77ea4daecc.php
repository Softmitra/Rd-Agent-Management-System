

<?php $__env->startSection('title', 'Lot Management'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h5 class="mb-0">Lot Management</h5>
        <div>
            <a href="<?php echo e(route(auth()->user()->id == 1 ? 'admin.lots.import' : 'agent.lots.import')); ?>" class="btn btn-success">
                <i class="fas fa-upload"></i> Import Lot
            </a>
            <a href="<?php echo e(route(auth()->user()->id == 1 ? 'admin.lots.create' : 'agent.lots.create')); ?>" class="btn btn-primary">
                <i class="fas fa-plus"></i> Create Lot
            </a>
        </div>
    </div>

    <!-- Search and Filters -->
    <div class="card mb-4">
        <div class="card-body">
            <form method="GET">
                <div class="row g-3">
                    <div class="col-md-3">
                        <label for="status" class="form-label">Status</label>
                        <select name="status" id="status" class="form-control">
                            <option value="">All Status</option>
                            <option value="draft" <?php echo e(request('status') == 'draft' ? 'selected' : ''); ?>>Draft</option>
                            <option value="processing" <?php echo e(request('status') == 'processing' ? 'selected' : ''); ?>>Processing</option>
                            <option value="completed" <?php echo e(request('status') == 'completed' ? 'selected' : ''); ?>>Completed</option>
                            <option value="verified" <?php echo e(request('status') == 'verified' ? 'selected' : ''); ?>>Verified</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label for="date_from" class="form-label">Date From</label>
                        <input type="date" name="date_from" id="date_from" value="<?php echo e(request('date_from')); ?>" class="form-control">
                    </div>
                    <div class="col-md-3">
                        <label for="date_to" class="form-label">Date To</label>
                        <input type="date" name="date_to" id="date_to" value="<?php echo e(request('date_to')); ?>" class="form-control">
                    </div>
                    <?php if(auth()->user()->id == 1): ?>
                    <div class="col-md-3">
                        <label for="agent_id" class="form-label">Agent</label>
                        <select name="agent_id" id="agent_id" class="form-control">
                            <option value="">All Agents</option>
                            <?php $__currentLoopData = \App\Models\Agent::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($agent->id); ?>" <?php echo e(request('agent_id') == $agent->id ? 'selected' : ''); ?>>
                                    <?php echo e($agent->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <?php endif; ?>
                </div>
                <div class="mt-3">
                    <button type="submit" class="btn btn-secondary">
                        <i class="fas fa-search"></i> Filter
                    </button>
                    <a href="<?php echo e(route(auth()->user()->id == 1 ? 'admin.lots.index' : 'agent.lots.index')); ?>" class="btn btn-outline-secondary">
                        <i class="fas fa-times"></i> Clear
                    </a>
                </div>
            </form>
        </div>
    </div>

    <!-- Results Summary -->
    <div class="d-flex justify-content-between align-items-center mb-3">
        <div>
            <span class="text-muted">
                Showing <?php echo e($lots->firstItem() ?? 0); ?> to <?php echo e($lots->lastItem() ?? 0); ?> 
                of <?php echo e($lots->total()); ?> results
            </span>
        </div>
    </div>

    <!-- Lots Table -->
    <div class="card">
        <div class="card-body">
            <?php if($lots->count() > 0): ?>
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead class="table-dark">
                            <tr>
                                <th>Lot Reference</th>
                                <th>Date</th>
                                <?php if(auth()->user()->id == 1): ?>
                                <th>Agent</th>
                                <?php endif; ?>
                                <th>Accounts</th>
                                <th>Amount</th>
                                <th>Commission</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $lots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <strong><?php echo e($lot->lot_reference_number); ?></strong>
                                        <?php if($lot->lot_description): ?>
                                            <br><small class="text-muted"><?php echo e($lot->lot_description); ?></small>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($lot->lot_date->format('d/m/Y')); ?></td>
                                    <?php if(auth()->user()->id == 1): ?>
                                    <td><?php echo e($lot->agent->name); ?></td>
                                    <?php endif; ?>
                                    <td><?php echo e($lot->total_accounts); ?> accounts</td>
                                    <td><strong>₹<?php echo e(number_format($lot->total_amount, 2)); ?></strong></td>
                                    <td>
                                        <strong>₹<?php echo e(number_format($lot->commission_amount, 2)); ?></strong>
                                        <br><small class="text-muted"><?php echo e($lot->commission_percentage); ?>%</small>
                                    </td>
                                    <td>
                                        <?php
                                            $statusColors = [
                                                'draft' => 'warning',
                                                'processing' => 'info',
                                                'completed' => 'success',
                                                'verified' => 'primary'
                                            ];
                                            $color = $statusColors[$lot->status] ?? 'secondary';
                                        ?>
                                        <span class="badge bg-<?php echo e($color); ?>">
                                            <?php echo e(ucfirst($lot->status)); ?>

                                        </span>
                                    </td>
                                    <td>
                                        <div class="btn-group">
                                            <a href="<?php echo e(route(auth()->user()->id == 1 ? 'admin.lots.show' : 'agent.lots.show', $lot)); ?>" 
                                               class="btn btn-sm btn-outline-info" title="View Details">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                            
                                            <?php if($lot->canBeModified()): ?>
                                                <a href="<?php echo e(route(auth()->user()->id == 1 ? 'admin.lots.edit' : 'agent.lots.edit', $lot)); ?>" 
                                                   class="btn btn-sm btn-outline-primary" title="Edit Lot">
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                            <?php endif; ?>
                                            
                                            <?php if($lot->import_errors && count($lot->import_errors) > 0): ?>
                                                <a href="<?php echo e(route(auth()->user()->id == 1 ? 'admin.lots.download-errors' : 'agent.lots.download-errors', $lot)); ?>" 
                                                   class="btn btn-sm btn-outline-danger" title="Download Errors">
                                                    <i class="fas fa-exclamation-triangle"></i>
                                                </a>
                                            <?php endif; ?>
                                            
                                            <?php if($lot->status == 'draft' || $lot->status == 'processing'): ?>
                                                <form method="POST" action="<?php echo e(route(auth()->user()->id == 1 ? 'admin.lots.finalize' : 'agent.lots.finalize', $lot)); ?>" class="d-inline">
                                                    <?php echo csrf_field(); ?>
                                                    <button type="submit" 
                                                            class="btn btn-sm btn-outline-success"
                                                            title="Finalize Lot"
                                                            onclick="return confirm('Are you sure you want to finalize this lot?')">
                                                        <i class="fas fa-check"></i>
                                                    </button>
                                                </form>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                <!-- Pagination -->
                <?php if($lots->hasPages()): ?>
                    <div class="d-flex justify-content-center mt-4">
                        <?php echo e($lots->withQueryString()->links()); ?>

                    </div>
                <?php endif; ?>
            <?php else: ?>
                <div class="text-center py-5">
                    <div class="text-muted">
                        <i class="fas fa-box fa-3x mb-3"></i>
                        <h5>No Lots Found</h5>
                        <p>Get started by creating your first lot or importing from Excel.</p>
                        <div class="mt-3">
                            <a href="<?php echo e(route(auth()->user()->id == 1 ? 'admin.lots.create' : 'agent.lots.create')); ?>" class="btn btn-primary">
                                <i class="fas fa-plus"></i> Create Your First Lot
                            </a>
                            <a href="<?php echo e(route(auth()->user()->id == 1 ? 'admin.lots.import' : 'agent.lots.import')); ?>" class="btn btn-success ml-2">
                                <i class="fas fa-upload"></i> Import From Excel
                            </a>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
$(document).ready(function() {
    // Auto-submit form on status change
    $('#status').change(function() {
        $(this).closest('form').submit();
    });

    // Tooltip initialization
    $('[title]').tooltip();
});
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\RD Agent20828\RD Agent\resources\views/lots/index.blade.php ENDPATH**/ ?>