<?php if(session()->has('account_status')): ?>
    <?php
        $status = session('account_status');
        $isExpired = $status['type'] === 'expired';
    ?>
    
    <div class="modal fade" id="accountExpirationModal" tabindex="-1" aria-labelledby="accountExpirationModalLabel" aria-hidden="true" 
         data-bs-backdrop="<?php echo e($isExpired ? 'static' : 'true'); ?>" data-bs-keyboard="<?php echo e($isExpired ? 'false' : 'true'); ?>">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header <?php echo e($isExpired ? 'bg-danger text-white' : 'bg-warning text-dark'); ?>">
                    <h5 class="modal-title" id="accountExpirationModalLabel">
                        <i class="fas fa-<?php echo e($isExpired ? 'exclamation-triangle' : 'clock'); ?> me-2"></i>
                        <?php echo e($isExpired ? 'Account Expired' : 'Account Expiring Soon'); ?>

                    </h5>
                    <?php if(!$isExpired): ?>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    <?php endif; ?>
                </div>
                <div class="modal-body">
                    <p><?php echo e($status['message']); ?></p>
                    
                    <?php if($isExpired): ?>
                        <p class="text-danger">
                            <strong>Expired on:</strong> <?php echo e($status['expired_at']); ?>

                        </p>
                    <?php else: ?>
                        <p class="text-warning">
                            <strong>Expires on:</strong> <?php echo e($status['expires_at']); ?>

                            <br>
                            <strong>Days remaining:</strong> <?php echo e($status['days_remaining']); ?>

                        </p>
                    <?php endif; ?>
                    
                    <div class="alert alert-info mt-3">
                        <h6 class="alert-heading"><i class="fas fa-info-circle me-2"></i>Contact Administrator</h6>
                        <p class="mb-0">Please contact the system administrator to <?php echo e($isExpired ? 'reactivate' : 'extend'); ?> your account.</p>
                        <hr>
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <strong>Email:</strong> admin@rdagent.com
                            </div>
                            <div>
                                <strong>Phone:</strong> +91 1234567890
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <?php if(!$isExpired): ?>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <?php endif; ?>
                    <a href="mailto:admin@rdagent.com" class="btn btn-primary">
                        <i class="fas fa-envelope me-2"></i>Email Admin
                    </a>
                </div>
            </div>
        </div>
    </div>
    
    <?php $__env->startPush('styles'); ?>
    <style>
        <?php if($isExpired): ?>
        /* Darker backdrop for expired accounts */
        .modal-backdrop.show {
            opacity: 0.8;
        }
        
        /* Disable scrolling when modal is open */
        body.modal-open {
            overflow: hidden;
            padding-right: 0 !important;
        }
        
        /* Make the modal more prominent */
        #accountExpirationModal .modal-content {
            border: 3px solid #dc3545;
            box-shadow: 0 0 20px rgba(220, 53, 69, 0.5);
        }
        <?php endif; ?>
    </style>
    <?php $__env->stopPush(); ?>
    
    <?php $__env->startPush('scripts'); ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var accountExpirationModal = new bootstrap.Modal(document.getElementById('accountExpirationModal'));
            accountExpirationModal.show();
            
            <?php if($isExpired): ?>
            // Prevent clicking outside the modal
            document.getElementById('accountExpirationModal').addEventListener('hide.bs.modal', function (event) {
                event.preventDefault();
                event.stopPropagation();
                return false;
            });
            
            // Disable all links and buttons outside the modal
            document.body.addEventListener('click', function(event) {
                if (!event.target.closest('#accountExpirationModal')) {
                    event.preventDefault();
                    event.stopPropagation();
                }
            }, true);
            
            // Additional code to prevent modal from being dismissed
            var modalElement = document.getElementById('accountExpirationModal');
            
            // Prevent ESC key from closing the modal
            document.addEventListener('keydown', function(event) {
                if (event.key === 'Escape') {
                    event.preventDefault();
                    event.stopPropagation();
                }
            });
            
            // Prevent clicking on backdrop from closing the modal
            modalElement.addEventListener('click', function(event) {
                if (event.target === modalElement) {
                    event.preventDefault();
                    event.stopPropagation();
                }
            });
            
            // Override the bootstrap modal's hide method
            var originalHide = bootstrap.Modal.prototype.hide;
            bootstrap.Modal.prototype.hide = function() {
                if (this._element.id === 'accountExpirationModal' && <?php echo json_encode($isExpired, 15, 512) ?>) {
                    return false;
                }
                return originalHide.apply(this, arguments);
            };
            <?php endif; ?>
        });
    </script>
    <?php $__env->stopPush(); ?>
<?php endif; ?> <?php /**PATH C:\xampp\htdocs\RD Agent20828\RD Agent\resources\views/components/account-expiration-popup.blade.php ENDPATH**/ ?>